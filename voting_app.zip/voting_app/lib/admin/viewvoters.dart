import 'package:flutter/material.dart';

class ViewVoter extends StatefulWidget {
  @override
  _ViewVoterState createState() => _ViewVoterState();
}

class _ViewVoterState extends State<ViewVoter> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
