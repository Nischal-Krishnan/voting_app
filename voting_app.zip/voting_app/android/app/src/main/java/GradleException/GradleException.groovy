package GradleException

class GradleException {
    GradleException(String s) {

    }
}
